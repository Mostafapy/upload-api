const uploadDocs = require('./upload-docs');


module.exports = {
  ...uploadDocs,
};