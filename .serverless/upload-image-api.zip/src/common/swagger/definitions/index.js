const uploadDefinitions = require('./upload-definitions');

module.exports = {
  ...uploadDefinitions,
};